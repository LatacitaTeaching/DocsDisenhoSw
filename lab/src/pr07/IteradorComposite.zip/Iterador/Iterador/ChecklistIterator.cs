﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IteratorComposite.Composite;

namespace IteratorComposite.Iterador
{
    /// <summary>
    ///     Clase que proporciona un iterador sobre una lista 
    ///     de comprobación compuesta (checklist).
    ///     Dentro del patrón composite corressponde a los nodos.
    /// </summary>
    public class IteradorChecklist : IEnumerator<ChecklistElement>
    {

        #region Atributos y Propiedades

        /// <summary>
        ///     Elemento actual al que apunta el iterador. Recuperable
        ///     a través de la propiedad Current. Cuando se crea el 
        ///     iterador y antes de su primer movimiento, su valor es 
        ///     null. 
        /// </summary>
        /// <inv>(this.MoveNext() implies (current != null))</inv>
        protected ChecklistElement current = null;
        
        /// <summary>
        ///     Referencia a la lista de comprobación que este iterador 
        ///     ha de recorrer.
        /// </summary>
        /// <inv>(theChecklist != null)</inv>
        protected Checklist theChecklist;

        /// <summary>
        ///     Iterador sobre la lista de hijos de la lista de 
        ///     comprobación.
        /// </summary>
        protected IEnumerator<ChecklistElement> childrenIterator   = null;

        /// <summary>
        ///     Iterador sobre el hijo de la lista de comprobación 
        ///     que estemos actualmente recorriendo.
        /// </summary>
        protected IEnumerator<ChecklistElement> currentChildIterator = null;

        /// <summary>
        ///     El elemento actualmente referenciado por el iterador.
        /// </summary>
        public ChecklistElement Current
        {
            get
            {
                return current;
            } // get
        } // Current

        /// <summary>
        ///     <see cref="IteradorChecklist.Current"/>
        ///     Este método se añade aquí por compatibilidad con las versiones
        ///     no genéricas del lenguaje.
        /// </summary>
        object IEnumerator.Current
        {
            get
            {
                return this.current;
            } // get
        } // IEnumerator.Current

        #endregion

        #region Constructores

        /// <summary>
        ///    Crea un nuevo iterador sobre la lista de comprobación pasada como 
        ///    parámetro.
        /// </summary>
        /// <param name="cl">
        ///     La lista de comprobación sobre la que iterará el iterador creado.
        /// </param>
        public IteradorChecklist(Checklist cl)
        {
            this.theChecklist  = cl;
        } // IteradorChecklist

        #endregion

        #region Interfaz del Iterador

        /// <summary>
        ///     Libera los recursos utilizados por el iterador antes de que éste se destruya.
        /// </summary>
        public void Dispose() { }

        /// <summary>
        ///     Avanza el iterador si aún quedan elementos por recorrer, situando su propiedad
        ///     Current en el siguiente elemento
        /// </summary>
        /// <returns>
        ///     Devuelve verdadero si se ha podido avanzar el iterador. Devuelve falso si el iterador 
        ///     ha finalizado y no quedan más elementos por recorrer. 
        /// </returns>
        public bool MoveNext()
        {
            // Variable que guarda el resultado a devolver. Inicialmente se considera que el iterador 
            // no se puede mover.
            bool moved = false;

            // Si current es igual a null, es porque es la primera vez que nos movemos. 
            // En este caso, debemos hacer que current apunte a la raíz de la lista de comprobación. 
            // e indicar que nos hemos movido.
            if (current == null)
            {
                // Apuntamos current a la raíz de la lista de comprobación.
                current = theChecklist;
                // Indicamos que nos hemos movido.
                moved  = true;
            }
            // Si current es distinto de null, es que nos hemos movido al menos una vez. Por 
            // tanto, debemos empezar a movernos por los hijos.
            // Si childrenIterator es igual a null, es porque es la segunda vez que nos vamos
            // a mover y por tanto debemos crear el iterador sobre los hijos.
            else if (childrenIterator == null)
            {
                // Obtenemos un iterador para los hijos. 
                // NOTA: Items nunca puede ser null. Si la lista de comprobación no tuviese 
                //       hijos, Items tendría una lista vacía, pero no sería null.
                childrenIterator = theChecklist.Items.GetEnumerator();
                // Intentamos avanzar el iterador de los hijos para colocarlo en el primer
                // hijo. 
                // En el caso de que la lista de comprobación no tenga subelementos, este 
                // iterador no se podría avanzar nunca, por lo que deberíamos acabar.
                if(childrenIterator.MoveNext())
                {
                    // Si hay algún hijo, colocamos el iterador de los hijos apuntando al 
                    // primer elemento de la lista de subelementos de la lista de compronación.
                    iniatilizeIteratorOverChild();
                    // Además, indicamos que hemos tenido éxito y nos hemos movido.
                    moved = true;
                } // if
            }
            /// Si childrenIterator es distinto de null, es que hemos empezado a movernos por los hijos.
            /// Además, si currentChildIterator es distitno de null es que hemos conseguido movernos al 
            /// menos a un hijo.
            /// Por lo tanto, intentamos movernos al siguiente nodo del iterador sobre el hijos actual. 
            else if ((currentChildIterator != null) && (currentChildIterator.MoveNext())) {
                // Si hemos podido movernos, hacemos que current apunte al mismo current del iterador sobre 
                // los hijos.
                current = currentChildIterator.Current;
                // Como nos hemos movido, lo señalamos
                moved = true;
            }
            /// Si no nos podemos mover utilizando el iterador sobre el hijo actual, es porque hemos terminado 
            /// de recorrer ese hijo de manera completa. Por tanto, debemos movernos al siguiente hijo, si lo 
            /// hubiere y empezar a recorrerlo. Por tanto, intentamos avanzar childrenIterator, que por las 
            /// condiciones de las ramas anteriores, sabemos que es distinto de null.
            else if (childrenIterator.MoveNext())
            {
                // Si hemos conseguido movernos al siguiente hijo, inicializamos el iterador sobre el hijo actual
                // para poder movernos sobre él.
                iniatilizeIteratorOverChild();
                // Como nos hemos movido, lo señalizamos.
                moved = true;
            } // if 

            return moved;

        } // MoveNext

        /// <summary>
        ///     Devolvemos el iterador a su estado inicial
        /// </summary>
        public void Reset()
        {
            current = null;
            childrenIterator = null;
        } // Reset

        #endregion

        #region Métodos privados de soporte

        /// <summary>
        ///     Asumiendo que hemos movido el iterador sobre el conjunto de los 
        ///     hijos (childrenIterator) a un nuevo hijo, creamos un nuevo iterador 
        ///     para recorrer dicho hijo y lo colocamos apuntando a su nodo raíz.
        /// </summary>
        protected void iniatilizeIteratorOverChild()
        {
            // Creamos un iterador para recorrer el nuevo hijo al que apunta childreInterator
            // y lo almacenamos en currentChildIterator.
            // Puesto que hemos movido childrenIterarorm childrenIterator.Current != null.
            currentChildIterator = childrenIterator.Current.GetEnumerator();
            // Los iteradores sobre ChecklistElement siempre se pueden mover al
            // menos un elemento, por lo que movemos el iterador creado y lo situamos en el 
            // primer elemento.
            currentChildIterator.MoveNext();
            // Hacemos que nuestro atributo current apunte a la misma posición 
            // que el current del nuevo iterador creado. 
            current = currentChildIterator.Current;

        } // iniatilizeIteratorOverChild

        #endregion

    } // class

} // namespace
