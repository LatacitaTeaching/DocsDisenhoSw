﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr06_Observer.SparrowElements
{
    public interface ISparrowElement
    {
    }
}
