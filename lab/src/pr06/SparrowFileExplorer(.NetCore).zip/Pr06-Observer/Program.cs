﻿using Pr02_Composite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SparrowFileExplorer
{
    static class Program
    {

        static IElementoSparrow crearSistemaEjemplo()
        {
            Directorio dRaiz = new Directorio("Raiz");

            Directorio dVacio = new Directorio("Directorio Vacio");

            dRaiz.SubElementos.Add(dVacio);

            Directorio dUnico = new Directorio("Directorio Con Archivo Unico");
            Fichero f01 = new Fichero("foto001.jpg", 200);
            dUnico.SubElementos.Add(f01);

            dRaiz.SubElementos.Add(dUnico);

            Directorio d01 = new Directorio("Directorio Vacio En Archivo Comprimido");
            Fichero f02 = new Fichero("foto003.jpg", 200);
            EnlaceDirecto e01 = new EnlaceDirecto(f01);

            CarpetaComprimida ccSimple = new CarpetaComprimida("ccSimple.zip");
            ccSimple.SubElementos.Add(f02);
            ccSimple.SubElementos.Add(e01);
            ccSimple.SubElementos.Add(d01);

            Directorio dComprimido = new Directorio("Directorio Con Archivo Comprimido Simple");

            Fichero f03 = new Fichero("foto002.jpg", 200);
            EnlaceDirecto e02 = new EnlaceDirecto(f01);

            dComprimido.SubElementos.Add(f03);
            dComprimido.SubElementos.Add(e02);
            dComprimido.SubElementos.Add(ccSimple);

            dRaiz.SubElementos.Add(dComprimido);

            Fichero f04 = new Fichero("foto007.jpg", 200);
            CarpetaComprimida ccAnidada = new CarpetaComprimida("ccAnidada.zip");
            ccAnidada.SubElementos.Add(f04);
            Fichero f05 = new Fichero("foto008.jpg", 200);

            CarpetaComprimida ccCompuesto = new CarpetaComprimida("ccComplejo.zip");
            ccCompuesto.SubElementos.Add(ccAnidada);
            ccCompuesto.SubElementos.Add(f05);

            Fichero f06 = new Fichero("foto005", 200);
            Fichero f07 = new Fichero("foto006", 200);

            Directorio dComprimidoCompuesto = new Directorio("Directorio con Archivo Comprimido Complejo");
            dComprimidoCompuesto.SubElementos.Add(f06);
            dComprimidoCompuesto.SubElementos.Add(f07);
            dComprimidoCompuesto.SubElementos.Add(ccCompuesto);

            Fichero f08 = new Fichero("foto004.jpg", 200);
            EnlaceDirecto e03 = new EnlaceDirecto(ccSimple);
            EnlaceDirecto e04 = new EnlaceDirecto(dVacio);

            Directorio dMultinivel = new Directorio("Directorio con Directorio Anidado");

            dMultinivel.SubElementos.Add(f08);
            dMultinivel.SubElementos.Add(e03);
            dMultinivel.SubElementos.Add(e04);
            dMultinivel.SubElementos.Add(dComprimidoCompuesto);

            dRaiz.SubElementos.Add(dMultinivel);

            return dRaiz;
        }

        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            MultiWindowRunner runner = new MultiWindowRunner();

            IElementoSparrow fs = crearSistemaEjemplo();
            FileExplorerView fev = new FileExplorerView(runner);
            fev.addFileSystem(fs);

            FileNameEditor fne = new FileNameEditor(runner);
            fne.addFileSystem(fs);

            runner.registerForm(fne);
            runner.registerForm(fev);

            runner.run();
        }
    }
}
