﻿using System;
using System.Windows.Forms;
using Pr02_Composite;


namespace SparrowFileExplorer
{
    public partial class SparrowElementViewerCtrl: UserControl
    {
        #region Attributes and Properties

        protected IElementoSparrow sparrowElement;

        public virtual IElementoSparrow SparrowElement
        {
            get
            {
                return sparrowElement;
            } // get
            set
            {
                if (value != null)
                {
                    this.sparrowElement = value;
                    displayElement();
                } // if
            } // set
        } // ElementoSparrow

        #endregion

        #region Constructor

        public SparrowElementViewerCtrl()
        {
            InitializeComponent();
        }

        #endregion

        #region Utility Private Methods

        protected void displayElement()
        {
            this.lb_NameText.Text = this.sparrowElement.Nombre;
            this.lb_SizeText.Text = this.sparrowElement.Tamanho.ToString();
        }

        #endregion

        private void SparrowElementViewer_Resize(object sender, EventArgs e)
        {
            this.tbl_Layout.Height = this.Height;
            this.tbl_Layout.Width = this.Width;
        }


    }
}
