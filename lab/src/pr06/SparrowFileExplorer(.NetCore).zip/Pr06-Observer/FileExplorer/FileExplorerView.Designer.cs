﻿using Pr02_Composite;
using System.Windows.Forms;

namespace SparrowFileExplorer
{
    partial class FileExplorerView
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.FileSystemTreeViewer = new System.Windows.Forms.TreeView();
            this.marcoElementos = new System.Windows.Forms.GroupBox();
            this.spv_ElementViewer = new SparrowFileExplorer.SparrowElementViewerCtrl();
            this.marcoElementos.SuspendLayout();
            this.SuspendLayout();
            // 
            // FileSystemTreeViewer
            // 
            this.FileSystemTreeViewer.Location = new System.Drawing.Point(11, 13);
            this.FileSystemTreeViewer.Name = "FileSystemTreeViewer";
            this.FileSystemTreeViewer.Size = new System.Drawing.Size(457, 439);
            this.FileSystemTreeViewer.TabIndex = 0;
            this.FileSystemTreeViewer.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.onElementSelected);
            // 
            // marcoElementos
            // 
            this.marcoElementos.Controls.Add(this.spv_ElementViewer);
            this.marcoElementos.Location = new System.Drawing.Point(484, 13);
            this.marcoElementos.Name = "marcoElementos";
            this.marcoElementos.Size = new System.Drawing.Size(315, 76);
            this.marcoElementos.TabIndex = 1;
            this.marcoElementos.TabStop = false;
            this.marcoElementos.Text = "Elemento";
            // 
            // spv_ElementViewer
            // 
            this.spv_ElementViewer.BackColor = System.Drawing.SystemColors.Window;
            this.spv_ElementViewer.Location = new System.Drawing.Point(10, 19);
            this.spv_ElementViewer.Name = "spv_ElementViewer";
            this.spv_ElementViewer.Size = new System.Drawing.Size(299, 51);
            this.spv_ElementViewer.SparrowElement = null;
            this.spv_ElementViewer.TabIndex = 0;
            // 
            // FileExplorerView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 464);
            this.Controls.Add(this.marcoElementos);
            this.Controls.Add(this.FileSystemTreeViewer);
            this.Name = "FileExplorerView";
            this.Text = "Sparrow File Explorer";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.onClose);
            this.marcoElementos.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        #region Atributos correspondientes a widgets

        private System.Windows.Forms.TreeView FileSystemTreeViewer;
        private GroupBox marcoElementos;
        private SparrowElementViewerCtrl spv_ElementViewer;

        #endregion
    }
}

