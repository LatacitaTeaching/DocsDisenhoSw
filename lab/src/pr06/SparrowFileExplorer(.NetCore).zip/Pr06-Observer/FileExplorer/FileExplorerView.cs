﻿using Pr02_Composite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SparrowFileExplorer
{
    /// <summary>
    ///     Ventana que aloja el Explorador de Archivos
    /// </summary>
    public partial class FileExplorerView : Form
    {
        /// <summary>
        ///     Dependencia con el monitor de ejecución de ventanas
        /// </summary>
        protected MultiWindowRunner runner;

        /// <summary>
        ///     Constructor de la ventana
        /// </summary>
        /// <param name="runner">
        ///     Monitor de ejecución que controla si se han cerrado todas 
        ///     las ventanas para entonces cerrar la aplicación también.
        /// </param>
        public FileExplorerView(MultiWindowRunner runner)
        {
            // Método generado por Visual Studio
            InitializeComponent();
            // Añadimos este formulario al monitor de ventanas
            this.runner = runner;
        } // FileExplorerView

        /// <summary>
        ///   Controlador de eventos que se ejecuta cuando se cierra el
        ///   formulario.
        /// </summary>
        /// <param name="sender">
        ///     Generado por Visual Studio, no se utiliza.
        /// </param>
        /// <param name="e">
        ///     Generado por Visual Studio, no se utiliza.
        /// </param>
        protected void onClose(object sender, FormClosedEventArgs e)
        {
            // Informamos al monitor de ventanas acerca de que este formulario
            // se ha cerrado
            runner.formClosed(this);
        } // onClose

        /// <summary>
        ///     Controlador de eventos que se invoca cuando se genera un elemento. 
        /// </summary>
        /// <param name="sender">
        ///     Generado por Visual Studio, no se utiliza.
        /// </param>
        /// <param name="e">
        ///     Generado por Visual Studio, no se utiliza.
        /// </param>
        protected void onElementSelected(object sender, TreeViewEventArgs e)
        {
            // Extraemos el nodo y lo convertimos a Sparrow Node, al no 
            // tener este widget una versión genérica
            SparrowNode selected = (SparrowNode) e.Node;
            // Hacemos que el visualizador de propiedades visualice este 
            // elemento
            this.spv_ElementViewer.SparrowElement = selected.ReferencedElement;
        } // onElementSelected

        /// <summary>
        ///     Incopora un sistema de archivos al Explorador de Archivos
        ///     para su visualización.
        /// </summary>
        /// <param name="fs">
        ///     El sistema de archivos a visualizar.
        /// </param>
        public void addFileSystem(IElementoSparrow fs)
        {
            TreeNode root = this.SistemaArchivo2Node(fs);
            this.FileSystemTreeViewer.Nodes.Add(root);
        } // addFileSystem

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fs"></param>
        /// <returns></returns>
        protected TreeNode SistemaArchivo2Node(IElementoSparrow fs)
        {

            TreeNode result = new SparrowNode(fs);

            // Esto es una chapuza que solucionaré para el próximo 
            // curso utilizando el patrón Adapter
            if (fs.GetType().IsSubclassOf(typeof(ContenedorSparrow)))
            {
                ContenedorSparrow contenedor = (ContenedorSparrow) fs;

                foreach (IElementoSparrow s in contenedor.SubElementos)
                {
                    TreeNode newChild = SistemaArchivo2Node(s);
                    result.Nodes.Add(newChild);
                } // foreach
            }

            return result;
        }
    }
}
