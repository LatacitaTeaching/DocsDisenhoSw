﻿using Pr02_Composite;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SparrowFileExplorer
{
    public partial class FileNameEditor : Form
    {
        protected MultiWindowRunner runner;
        protected List<IElementoSparrow> displayedElements = new List<IElementoSparrow>();
   
        public FileNameEditor(MultiWindowRunner runner)
        {
            InitializeComponent();
            this.runner = runner;
        }

        private void onClose(object sender, FormClosedEventArgs e)
        {
            this.runner.formClosed(this);
        }

        public void addFileSystem(IElementoSparrow sa)
        {
            processSistemaArchivos(sa);
        }

        private void processSistemaArchivos(IElementoSparrow sa)
        {
            createNewCell(sa);

            if (sa.GetType().IsSubclassOf(typeof(ContenedorSparrow))) { 

                ContenedorSparrow contenedor = (ContenedorSparrow) sa;

                foreach (IElementoSparrow s in contenedor.SubElementos)
                {
                    processSistemaArchivos(s);
                } // foreach
            } // if
        }

        private void createNewCell(IElementoSparrow sa)
        {
            DataGridViewCell cell = new DataGridViewTextBoxCell();
            cell.Value = sa.Nombre;
            this.displayedElements.Add(sa);

            DataGridViewRow row = new DataGridViewRow();
            row.Cells.Add(cell);

            this.gv_ElementsView.Rows.Add(row);
        }

        private void onCellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int row = e.RowIndex;
            String newName = this.gv_ElementsView.Rows[row].Cells[0].Value.ToString();
            displayedElements[row].Nombre = newName;

        }
    }
}
