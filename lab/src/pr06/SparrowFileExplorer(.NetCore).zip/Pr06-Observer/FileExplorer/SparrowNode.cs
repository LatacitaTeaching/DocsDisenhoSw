﻿using Pr02_Composite;
using Pr06_Observer;
using System.Windows.Forms;

namespace SparrowFileExplorer
{
    public class SparrowNode : TreeNode
    {

        protected IElementoSparrow referencedElement;

        public SparrowNode(IElementoSparrow sa) : base(sa.Nombre)
        {
            this.referencedElement = sa;
            this.Text = referencedElement.Nombre;
        } // SparrowNode

        public IElementoSparrow ReferencedElement
        {
            get
            {
                return referencedElement;
            }
        }

        public void onNameChanged(IElementoSparrow element)
        {
            this.Text = element.Nombre;
        } // onNamedChanged

    } // class SparrowNode 
} // namespace
