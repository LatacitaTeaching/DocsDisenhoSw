﻿using Pr02_Composite;
using Pr06_Observer;
using System.Windows.Forms;

namespace SparrowFileExplorer
{
    public class SparrowNode : TreeNode
    {

        protected IElementoSparrow referencedElement;

        public SparrowNode(IElementoSparrow sa) : base(sa.Nombre)
        {
            this.referencedElement = sa;
            this.Text = referencedElement.Nombre;
        } // SparrowNode

        public IElementoSparrow ReferencedElement
        {
            get
            {
                return referencedElement;
            }
        }

    } // class SparrowNode 
} // namespace
