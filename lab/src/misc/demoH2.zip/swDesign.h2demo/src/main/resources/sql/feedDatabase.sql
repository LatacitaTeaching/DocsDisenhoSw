INSERT INTO Pelicula VALUES (0,'Joker','Todd Phillips','USA');
INSERT INTO Pelicula VALUES (1,'Amanece que no es poco','Jos� Luis Cuerda','Espa�a');
INSERT INTO Pelicula VALUES (2,'Harakiri','Masaki Kobayashi','Jap�n');

