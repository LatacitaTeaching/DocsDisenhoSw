CREATE TABLE Pelicula (

	id       int not null,
	titulo   varchar(200) not null,
	director varchar(200) not null,
	nacionalidad varchar(50) not null,
	
	PRIMARY KEY (id)

);
